from datetime import datetime
from moodforge_main import generate_daily  # fake6.py must be in the same directory

BASE_DIR = "test_output"
num_trials = 5  

print("\n🔬 GRADE I and GRADE III PRODUCTION TEST STARTING...\n")

# 🟢 Grade I (Normal individual)
for i in range(num_trials):
    pid = f"test_G1_{i:02d}"
    print(f"🟢 Test G1-{i+1}: Forcing Grade 'I'...")
    generate_daily(
        pid=pid,
        date=datetime.today(),
        disordered=False,
        disorder_type=None,
        forced_grade="I"
    )

# 🟡 Grade III (Disordered individual)
for i in range(num_trials):
    pid = f"test_G3_{i:02d}"
    print(f"🟡 Test G3-{i+1}: Forcing Grade 'III'...")
    generate_daily(
        pid=pid,
        date=datetime.today(),
        disordered=True,
        disorder_type="Depression",  # example disorder
        forced_grade="III"
    )