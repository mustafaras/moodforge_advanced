# 🧠 MoodForge Advanced

**MoodForge Advanced** is a high-fidelity, multimodal simulation engine for **digital psychiatry** and **AI-supported psychiatric risk modeling**. It creates synthetic patients, simulates their daily psychological profiles, and evaluates them using natural language processing, emotion recognition, psychometric scores, and physical activity metrics.

---

## 🔬 What Does It Do?

- Simulates psychiatric patients with disorders like:
  - Depression, Anxiety, PTSD, Bipolar, Psychosis, OCD
  - As well as normal (Grade I-II) profiles
- Tracks daily mood variations and computes functioning scores
- Analyzes sentiment and emotions from journal entries, voice logs, and facial expressions
- Generates clinically structured psychometric forms (PHQ-9, GAD-7, etc.)
- Scores psychiatric risk (Grade I–V) using machine learning
- Visualizes changes with interactive Streamlit dashboards
- Explains model outputs using SHAP (Explainable ML)

---

## ⚙️ Technologies Used

- **Python 3.11+**
- **Streamlit** – User interface
- **scikit-learn** – Machine learning (Random Forest)
- **SHAP** – Explainability
- **OpenAI GPT-4 Turbo** – Clinical AI summaries
- **Plotly / Matplotlib** – Data visualization
- **Pandas / NumPy** – Data processing

---

## 🤖 Machine Learning & Risk Grading

MoodForge uses a trained **Random Forest Classifier** to predict psychiatric risk based on:

| Feature        | Description |
|----------------|-------------|
| `mood_avg`     | Average mood score (1–5) |
| `steps`        | Daily physical steps |
| `sleep`        | Daily sleep duration |
| `PHQ9`         | Depression score |
| `GAD7`         | Generalized anxiety |
| `PSS10`        | Perceived stress |
| `PSQI`         | Sleep quality |
| `IESR`         | PTSD symptom load |
| `functioning`  | Combined score (0–100) |

### 🏥 Output: Risk Grades (I–V)

- Grade I–II: Normal to mild symptoms
- Grade III–V: Clinical risk increases

### 🔍 Explainability with SHAP

- SHAP Waterfall and Bar plots are generated
- OpenAI explains feature contributions (e.g., "High PHQ-9 increased Grade IV risk")
- Clinically interpretable for psychiatrists and researchers

### 🛠️ Train the Model

```bash
python train_random_forest_model.py
```

The model is saved as:

```text
random_forest_risk_model.pkl
```

---

## 📈 Clinical Assessment Pipeline

1. **Data Collection**
   - Simulated mood, emotion, audio, journal, healthkit data
2. **Risk Evaluation**
   - Grade I–V via ML
3. **Visualization**
   - Mood heatmaps, function graphs, form score plots
4. **AI Summary**
   - GPT-based narrative report for each patient

---

## 🧬 Supported Psychometric Tools

- **PHQ-9**: Depression
- **GAD-7**: Anxiety
- **PSS-10**: Stress
- **PSQI**: Sleep quality
- **IES-R**: PTSD

Each score includes:
- Numerical score
- Severity level (normal, mild, moderate, severe)

---

## 🧠 Clinical AI Commentary

MoodForge provides GPT-4-generated clinical reports based on each patient's multimodal data including:

- Mood changes
- Emotion trends
- Functioning score
- Form severity
- NLP-derived sentiment

---

## 🧪 Scientific Basis

MoodForge is built upon the principles of:

- **RDoC (Research Domain Criteria)**
- **DSM-5 Diagnostic Framework**
- **Digital Phenotyping** (Torous et al., 2020)
- **Emotion research** (Ekman, Scherer)
- **ML in Psychiatry** (Luxton, 2020)

References used in simulation logic:
- APA (2013), WHO ICD-11 (2021)
- Kroenke et al. (2010), Spitzer et al. (2006)
- Buysse et al. (1989), Cohen et al. (1983)
- Insel et al. (2010), Linehan (2018)

---

## 🚀 Getting Started

1. Clone the repository:
```bash
git clone https://github.com/your-username/moodforge_advanced.git
cd moodforge_advanced
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set your OpenAI API key in `.env`:
```env
OPENAI_API_KEY=your_openai_key_here
```

4. Run the app:
```bash
streamlit run moodforge_main.py
```

---

## 📁 Directory Structure

```text
├── moodforge_main.py           # Main simulation logic
├── projection.py               # Intervention modeling
├── templates/                  # NLP and affective response templates
├── train_random_forest_model.py
├── test_grade.py               # Grade evaluation CLI
├── requirements.txt
└── data/
    └── records/
        └── <patient_id>/
```

---

## 🧠 Disclaimer

This is a research prototype intended for **simulation, education, and experimentation** in computational psychiatry. It does **not** replace clinical diagnosis or treatment. Use responsibly.

---

## 👨‍⚕️ Developed By

MoodForge Advanced is part of a broader research initiative on **AI-assisted psychiatry**, **digital mental health**, and **neuro-informatics**.

Feel free to contribute, cite, or fork!