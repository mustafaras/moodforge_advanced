JOURNAL_TEMPLATES = {
    "Depression": [
        "When I woke up this morning, I didn’t want to do anything. Everything started to feel meaningless. It’s as if the days are all the same and I’m always in the same place. I feel disconnected from the outside world.",
        "Today I couldn’t even leave my bed again. Even if I want to change something, I can’t find the strength inside me. I didn’t want to talk to my family. I’m tired and exhausted.",
        "Past mistakes keep running through my mind. I can’t forgive myself. I was silent all day. I had nothing to say. It feels like these feelings will never go away.",
        "I can’t believe people love me anymore. When I don’t get a reply to my messages, it feels like my world is falling apart. I can’t tolerate silence. But at the same time, I don’t want to see anyone.",
        "I can’t make any progress in my life. Every day is the same. Same breakfast, same faces, same feeling of emptiness. I’m in a pit and I can’t see a way out.",
        "Lately, I spend hours crying. Sometimes there’s not even a reason. My heart just feels heavy. The exhaustion is no longer just physical, my soul is tired too.",
        "I have no positive thoughts left about myself. I don’t even want to look in the mirror. I feel like a burden to others. I wish I could be invisible.",
        "Last night I couldn’t sleep again. The moment my head hit the pillow, all the memories came over me. I can’t close my eyes. I slept with the lights on.",
        "Loneliness has started to feel natural to me. Nobody calls me, and I don’t reach out to anyone. The silence eats away at me. I just want the day to end.",
        "I have no appetite. My stomach growls but when I eat, nothing has any taste. Every bite just feels like emptiness inside me. It’s just a habit at this point."
    ],
    "Bipolar": [
        "I woke up at 4am, filled with inspiration. I started writing a book. Then I cleaned the house, went out for a run. My energy never ends. I feel amazing!",
        "I woke up today with incredible brightness. I wanted to help everyone. I loved people, started new projects. At this pace, I could change the world.",
        "I realized while talking, my sentences follow each other rapidly. My thoughts flow quickly. It feels like no one can understand me. But I’m aware of everything.",
        "I maxed out my credit card. I don’t care if I get fired tomorrow. There’s a concert tonight and I have to be there. I was made to live!",
        "I looked at myself in the mirror and saw a leader. I can guide people. Maybe if I started a party, people would follow me. I’m making plans in my mind.",
        "My phone keeps ringing because I texted everyone. I’m talking to everyone at once. My ideas are exploding. There are no limits.",
        "Today I held an art exhibition in my mind. I even painted the pictures in my head. If I keep working at this pace, I’ll be done in a few days. Reality and dreams are mixed together.",
        "I didn’t eat because it’s a waste of time. I didn’t sleep because I’m full of energy. The world can’t keep up with me. Time moves slower for me.",
        "My friends are worried, but they just think more slowly. I’m different. I see the future in my mind. Things they’ll never understand.",
        "I feel like there’s a light in my eyes. I went out walking at night. Even the moon seemed to shine just for me. Everything has meaning during these times."
    ],
    "Psychotic": [
        "The voices are still coming. Sometimes they whisper, sometimes they shout. I don’t know who they are, but they guide me. People might be watching me.",
        "Reality feels like it’s changing. Scenes play out in my mind, but others can’t see them. Maybe the TV is sending me messages.",
        "I didn’t leave the house today because there are people watching me outside. I don’t know who they are, but their intentions aren’t good. I can’t even make eye contact anymore.",
        "A sentence I heard on the radio was exactly what I was thinking. That can’t be a coincidence. Someone might be reading my mind. Maybe a chip was implanted.",
        "When I look in the mirror, my eyes look like someone else’s. Sometimes even my own voice sounds strange. I feel like I’m forgetting who I am.",
        "When a police car passed by, I felt anxious. It’s as if they’re looking for me. I haven’t done anything, but I feel guilty.",
        "I sense threats in people’s facial expressions. Even if they smile, it’s like there’s something bad inside. Everyone seems to be acting.",
        "I can’t tell the difference between dreaming and being awake. I’m not sure what’s real and what’s a dream.",
        "It feels like shadows move in the dark. There’s no sound outside, but I feel pressure inside me. It’s like someone’s always watching, but I have no proof.",
        "I locked the doors twice. Turned off the lights but checked again. When I hear the sounds, it feels like something’s going to happen. That’s why I’m always on alert."
    ],
    "Anxiety": [
        "My heart was pounding like crazy before the meeting. My hands were sweaty. My voice trembled. It felt like everyone was judging me.",
        "There’s a constant feeling inside me that something bad is going to happen. Wherever I go, this inner tension follows me. I pay attention to everything, but it’s never enough.",
        "I had to go out today, but I couldn’t manage. Crowds suffocate me. As the noise rises, I feel anxious. I had to go back.",
        "When the phone rang, I jumped. Was it bad news? Every notification is a panic trigger. My mind never stops.",
        "Being stuck in traffic is a nightmare. If I’m alone in the car, I start to panic. My heartbeat speeds up, I sweat.",
        "I was invited to dinner but didn’t go. I spent hours worrying about what I’d say and how I’d act. Then I gave up.",
        "I checked everything before bed. Did I turn off the stove? Is the door locked? I thought about every possibility. Still, I wasn’t at ease.",
        "I thought I couldn’t breathe. Everything was closing in on me. It felt like my heart would burst. But then it passed—there was no reason.",
        "I feel like people are judging me. Every word, every move feels like it’s being analyzed. These thoughts never leave my mind.",
        "Every morning feels like an exam. I feel unprepared. Even an ordinary day feels like a battlefield."
    ],
    "PTSD": [
        "I woke up at night, trapped in nightmares. I keep seeing the same scenes over and over. There’s no way I’ll ever forget that moment. My body freezes, I can’t move.",
        "Noisy environments disturb me. When I hear a sound like an explosion, my body reacts. People around me can’t understand it.",
        "I can’t close off the past. When I close my eyes, my traumas come back. I lock every door just to feel safe.",
        "I remember even while awake. The sound of a car, a scream... It all takes me back to the past. It’s like I’m living it again.",
        "I don’t want to go out. People are too fast, too loud. There’s a constant tension as if something’s about to happen.",
        "People say ‘it’s over now’ but it’s not. Every night my body reacts with the same fear. It’s as if that day happens again.",
        "I don’t want to be touched. When someone comes close, I flinch. I need space. I want physical safety.",
        "Same nightmare, again and again. Every night. I wake up sweating. I’ve started sleeping with the lights on.",
        "During the day I’m normal but at night scenes from a movie replay in my head. I freeze with a sense of helplessness. I’m afraid to sleep.",
        "Crowds suffocate me. Even among people, I’m alone because nobody knows what I’ve been through."
    ],
    "OCD": [
        "I washed my hands, washed them again, still don’t feel clean. The thought of getting germs won’t go away. I can’t control my mind.",
        "I locked the door but wasn’t sure. Went back. Checked five times. Maybe I should look again. I’m not at ease.",
        "My thoughts repeat: If I don’t do this ritual, something bad will happen. I know it’s not logical, but I can’t stop.",
        "Every morning I have to brush my teeth, shower, and leave in the same order. If the order is broken, my day goes badly. I don’t know if it’s an obsession, but it calms me.",
        "Did I turn off the stove? I’m sure, but I checked anyway. Then checked again. It makes me feel safe, but wastes my time.",
        "Things need to be symmetrical. Otherwise I get restless. I’m always rearranging my desk at work.",
        "I’ve become obsessed with numbers. I avoid some numbers, see others as lucky. Sometimes I just start counting again and again.",
        "A thought came: if I don’t turn off the light three times, something will happen to my mom. I know it’s silly but I couldn’t stop.",
        "I was late because of my compulsions. It’s not easy to leave the house. I can’t relax until my rituals are done.",
        "People call me a ‘control freak’ but if they knew the restlessness inside me... It’s not just about order, it’s an inner compulsion."
    ],
    "Normal": [
        "I have a balanced mood in daily life. I do ordinary things like going to work and meeting friends.",
        "My emotions are balanced. Sometimes I laugh, sometimes I get lost in thought, but overall I’m at peace.",
        "I don’t have trouble communicating with people. I can make eye contact and feel comfortable in social situations.",
        "I feel safe. I have come to terms with my past experiences. I look to the future with hope.",
        "I pay attention to my physical health. I exercise regularly and try to eat healthy. I try to take good care of myself.",
        "Sometimes I have stressful moments but I have methods to overcome them. I use relaxation techniques.",
        "I can balance my work and personal life. I can manage both and this makes me happy.",
        "I make time for my hobbies. Doing things like painting or listening to music makes me happy.",
        "My relationships with family and friends are healthy. I can give and receive support.",
        "Even though there are uncertainties about the future, I make plans to overcome them and I trust myself.",
        "Today I felt calm and balanced. I had no trouble handling daily tasks.",
        "It was a routine day. I drank my morning coffee and went outside. Took a little walk.",
        "My mind was clear, my emotions were balanced. I finished the day with a sense of inner peace.",
        "Even though work was busy, my stress management was good. I didn’t have any emotional outbursts.",
        "I was socially relaxed. Talking to family and friends felt good.",
        "I had plenty of energy. Enjoyed little things. Overall, it was a positive day.",
        "I took time for myself. Meditated. Felt a sense of inner balance all day.",
        "Everything was under control. My sleep routine was good, too. The day was healthy.",
        "I felt creative. Coming up with new ideas felt good. My emotions were stable.",
        "I focused on my goals. Got my daily responsibilities done without delay."
    ]
}

def get_journal(disorder_type):
    import random
    templates = JOURNAL_TEMPLATES.get(disorder_type, JOURNAL_TEMPLATES["Normal"])
    return random.choice(templates)
