import random

EMOTIONS = ["happiness", "sadness", "anger", "anxiety", "neutral"]

def get_video_emotion_scores(dominant_emotion):
    return {
        "dominant_emotion": dominant_emotion,
        "emotion_scores": {
            e: round(random.uniform(0.5, 1.0), 2) if e == dominant_emotion else round(random.uniform(0.0, 0.4), 2)
            for e in EMOTIONS
        }
    }

VIDEO_TEMPLATES = {
    "Depression": [
        "Noticeable blankness on the face and avoidance of eye contact. Lips are turned down. Slow blinking.",
        "Eyes fixed to the ground, minimal expression. Chin is low, forehead is wrinkled. The whole face looks tired and collapsed.",
        "Eyebrows drawn together in the center, noticeable darkness under the eyes. Facial expressions indicate low energy.",
        "Mouth alternates between closed and slightly open. Limited movement, head bowed. Weak muscle tone around the eyes.",
        "Frequent deep breaths and avoidance of eye contact. Blank stares are present.",
        "Lips tremble while speaking, eyes appear teary. Facial muscles are relaxed. Expression is static.",
        "Almost zero emotional response. Head slightly down. Slouched posture. Delayed response.",
        "Sometimes it looks like the eyes are closing, a sign of fatigue. Eyebrows are constantly furrowed. Asymmetry in the mouth.",
        "Very little activity in the cheek muscles. Eye area is droopy. The face generally remains in a static position.",
        "Avoidant glances, gestures resisting tears. Weak nodding. Minimal eye contact."
    ],
    "Bipolar": [
        "Wide smile on the face, raised eyebrows. Eyes are sparkling. Excessive gesturing.",
        "Facial expressions are rapid and exaggerated. Intense eye contact. Frequent sudden head movements.",
        "Smile covers the whole face. Tapping or playing with hands is observed.",
        "Facial expressions lead the conversation. Intense support with gestures.",
        "Frequent eyebrow raising around the eyes. The expression is highly enthusiastic.",
        "Facial expression changes rapidly. Fluctuates between laughter and seriousness.",
        "Head is constantly moving. Eyes show hyperactivity. Facial expressions resemble a laughing fit.",
        "Facial expression is dramatic, like an actor. Eyebrows raised, mouth open.",
        "Steady and intense eye contact. The face has lively, but not tense, energy.",
        "Facial animation matches fast speech. Eyes are wide, forehead open, lips active."
    ],
    "Psychotic": [
        "Nervousness on the face. Eyes quickly move side to side. Frequent looking over the shoulder.",
        "Expressions do not follow each other. Meaningless grinning and avoidance of eye contact one after another.",
        "Eyes are fixed on a point, but the person appears to be communicating with someone who isn’t there.",
        "Eyebrows are constantly moving, but the expression is meaningless. Occasionally laughing into space.",
        "Expression changes are sudden and inappropriate. Irregular twitching of facial muscles.",
        "While mumbling to themselves, facial expression is disconnected from surroundings. Strange sparkle in the eyes.",
        "Wrinkle in the middle of the forehead, jaw clenching. Avoiding eye contact but suddenly staring intently.",
        "Head slightly tilted, expressions are intense on one side of the face. Fear and suspicion in the eyes.",
        "Unidentifiable facial expressions. Occasionally mouth movements as if talking to someone.",
        "Facial muscles seem constantly tense. Disturbing smile and sudden freezing are present."
    ],
    "Anxiety": [
        "Anxious facial expression. Eyebrows close together. Lips tightly closed.",
        "Tension around the eyes, frequent blinking. Facial tics. Head tilted down.",
        "Frequent hand-to-face gestures. Eye contact is broken and brief. Slightly raised eyebrows.",
        "Constantly scanning surroundings. Corners of the mouth pulled down. Panic in the eyes.",
        "Signs of dry mouth. Lip licking. Furrowed brows. Trembling chin.",
        "Rapid changes in expression. Uncertain look in the eyes. Wrinkle in the middle of the forehead.",
        "Micro-tremors in the head. Breathing is rapid. Tension in facial muscles.",
        "Frequent eye movements. Difficulty establishing eye contact. Slight trembling of the eyebrows.",
        "Excessive alertness in facial muscles. Occasional wiping of the face.",
        "Redness on the cheeks. Eyes wide open. Eyebrows fixed in a low position."
    ],
    "PTSD": [
        "Blankness after shock on the face. Eyes staring off into the distance. Almost no facial expression.",
        "Occasional startle reflex. Eyes lock onto a point and stay there.",
        "Gazing into space as if in another time. Muscles tense.",
        "Sudden facial tension followed by relaxation. Signs of aging in the eyes.",
        "Slow and thoughtful blinking. Pronounced wrinkle in the center of the forehead.",
        "If eye contact is established, it doesn't last long. Face shows a return to the past.",
        "Alert facial expression. Eyes scan the environment. Eyebrows constantly raised.",
        "During rapid breathing, facial muscles tense involuntarily.",
        "Fearful gaze in the eyes. Intense but speechless facial expression changes.",
        "Face looks as if it could cry at any moment. Eyes are wet, lips trembling."
    ],
    "OCD": [
        "Nervousness and indecision on the face. Eyes quickly scan the surroundings.",
        "Eyebrows raised and corners of the mouth tight. Excessive blinking.",
        "Hand-to-face gestures, wiping forehead. Eyes show intense concentration.",
        "Persistent ‘uncertainty’ expression. Brief flashes of panic in the eyes.",
        "Expressions try to be symmetrical. Eyebrows symmetrical but very tense.",
        "Lips drawn in. Eyes focused on a narrow spot. Forehead is tense.",
        "Furrowing brows and avoiding eye contact occur together. Constant worried look.",
        "Shaking head from side to side. Rapid repetition of facial expressions.",
        "Makes eye contact but then immediately avoids it. Repetitive mouth movements.",
        "Deliberate facial correction. Fixing hair and checking eyebrows with hands."
    ],
    "Normal": [
        "Facial expression is balanced, eyebrows and lips in a neutral position.",
        "Eye contact is present. Neither exaggerated nor blank. Moderate activity in facial expressions.",
        "Facial muscles are symmetrical and relaxed. Emotional appearance is balanced.",
        "Smile is gentle and natural. Area around the eyes is not tense. Overall relaxation dominates.",
        "Head and face movements are harmonious. No signs of stress or agitation."
    ]
}

def get_video(disorder_type):
    return VIDEO_TEMPLATES.get(disorder_type, VIDEO_TEMPLATES["Normal"])
