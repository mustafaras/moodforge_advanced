AUDIO_TEMPLATES = {
    "Depression": [
        "My voice echoes inside me, but it feels like no one hears. Why am I here? I don't know where I'm going. Everything is gray, I taste nothing, I hear nothing.",
        "Fatigue is no longer just in my body, but deep in my soul. Even when I close my eyes, the darkness speaks to me.",
        "There’s a sentence that repeats inside me: 'Nothing will ever change.' This thought drains all my motivation.",
        "The only thing I tell myself is: 'There’s no point.' People laugh, but inside, I am screaming.",
        "There’s a fog in my mind. I can’t even describe how I feel. Just emptiness... Infinite emptiness.",
        "Sometimes I want to cry, but it’s as if I have no tears left. An inner weight presses down, I can’t breathe.",
        "Every breath reminds me of the weight of my existence. Even if someone talks to me, it’s like I’m not really there.",
        "Time has stopped. I just watch the walls. There is nothing stirring inside, I feel like a frozen dream.",
        "I don’t even pray when I go to bed anymore. I think to myself, it would be better if I didn’t wake up.",
        "I can't stand it when people say 'It will pass.' When? How? Who will silence this echo inside me?"
    ],
    "Bipolar": [
        "It’s like there’s an orchestra in my mind, every instrument playing a different melody but I can hear them all at once!",
        "I’m talking, explaining, planning. I can’t stop myself. Anything is possible, everything is now!",
        "My voice echoes in my head: 'You’re special, you came to this world to change things!'",
        "I try to sleep, but my thoughts are like race cars. Each one wants to be ahead.",
        "Sometimes I feel like a god. As if the universe expands with my ideas.",
        "I pick up my phone, I want to text everyone. Everyone should hear me, everyone!",
        "I’m neither hungry nor sleepy. Time moves slowly for me. People can’t understand me, because I’m higher up.",
        "There’s an explosion of ideas in my head. If I wrote, it would be a book; if I spoke, it would move crowds.",
        "My thoughts are like a painting. Colorful, striking, pushing the limits of logic.",
        "My energy is like a nuclear reactor. Stop? Never. I’m just getting started!"
    ],
    "Psychotic": [
        "Someone is watching me. I’m not sure, but I heard the voices. They’re in my head, but they feel real.",
        "My eyes are open, but it feels like the world doesn’t belong to me. There’s a curtain between me and reality.",
        "Someone is whispering in my ear. Said my name. But I was home alone. I’m sure.",
        "The news anchor on TV looked at me. Winked. Must know me.",
        "Someone passing on the street might be following me. We made eye contact. My heart sank.",
        "Everything is losing meaning. Words are mixing up, sounds turning into screams.",
        "The walls seem to be breathing. There’s an eye, I think, watching me.",
        "The voice in my head tells me what to do. Sometimes harsh, sometimes sad.",
        "When I looked in the mirror, I saw a different face. It was me, but also not me.",
        "People don’t understand me because they live in another reality. Mine is more real."
    ],
    "Anxiety": [
        "My heart feels like it’s going to jump out of my chest. No reason, but fear is everywhere.",
        "My mind keeps creating scenarios. Feels like everything will go wrong. At any moment.",
        "My inner voice warns me: 'Be ready, something will happen.' But I don’t know what it is.",
        "Every sound, every touch is a danger signal. My muscles are tense, my hands cold.",
        "My thoughts are suffocating. Breathing is getting harder. It feels like the ceiling is coming down on me.",
        "Just when I think I’m relaxed, the anxiety inside rises up again.",
        "Before going out, I checked my bag three times. Still feels like something is missing.",
        "It’s as if everyone’s eyes are on me. No matter what I say, it’ll be misunderstood.",
        "I tell myself 'You’re being silly,' but my body doesn’t listen. Panic takes over everything.",
        "Before going to sleep, I checked the lights ten times. Still restless. The danger isn’t over."
    ],
    "PTSD": [
        "I wake up suddenly at night, covered in sweat. Same nightmares. Sounds, images, screams.",
        "Even a normal sound startles me. My heart races, my eyes scan everywhere.",
        "I can’t forget that moment. It keeps replaying before my eyes. I want to escape, but it’s impossible.",
        "Even a little noise puts my body on alert. Like I’m on a battlefield.",
        "While talking to people, I zone out. For a moment, I’m back in the past, then back to now.",
        "I constantly feel threatened. Nowhere feels safe.",
        "My mind proves the past wasn’t just a dream. Sounds and smells remind me of everything.",
        "Even the sound of a car braking brings back the trauma. Time freezes, my body locks up.",
        "Same dreams, same scenes every night. Sleep is a nightmare. I can’t close my eyes.",
        "People don’t understand. I’m not just reliving an event—I’m living it again every day."
    ],
    "OCD": [
        "There’s a thought repeating in my head: If I don’t do it, something bad will happen.",
        "My hands felt like they’d burn, but I washed them again. Again. One more time.",
        "Did I turn off the light? Not sure. I have to check. Right now. Again.",
        "Nothing goes right without my rituals. They’re a necessity for me.",
        "Everything must be symmetrical. If left and right aren’t equal, my day is ruined.",
        "My thoughts are playing tricks on me. But I can’t risk it. I have to check.",
        "I started counting out loud. 1-2-3-4... That gives me a sense of security.",
        "If I don’t do something, something will happen to my mom. It’s not just a thought. It’s real.",
        "People say ‘You’re exaggerating.’ But they don’t know. It’s a war. Inside.",
        "Before leaving, I checked the stove five times. Still don’t feel at peace."
    ],
    "Normal": [
        "My voice is steady and calm. My thoughts are clear and fluent.",
        "The peace inside me reflects outside. It’s easy to express myself.",
        "My emotions are balanced. Not too much, not too little. Just right.",
        "My communication with people is fluent. I have no trouble making eye contact.",
        "I feel comfortable. My thoughts aren’t bothering me.",
        "My tone of voice is balanced. Not too loud, not too soft.",
        "My eyes are open, I’m aware of my surroundings. Everything is in its place.",
        "I’m aware of my emotions but can control them.",
        "My rhythm in communication is natural. Not too fast, not too slow.",
        "I’m confident. The voice inside doesn’t steer me."
    ]
}

def get_audio(label):
    """Return simulated audio transcript content based on label"""
    if label == "Depression":
        return "Audio recording: I feel nothing... It’s so hard to keep going like this..."
    elif label == "Bipolar":
        return "Audio recording: I FEEL AMAZING TODAY! MY LIFE IS FINALLY ON TRACK!"
    elif label == "Psychotic":
        return "Audio recording: The voices coming from the radio are talking about me..."
    elif label == "Anxiety":
        return "Audio recording: I can’t breathe... What if something happens... I’m so anxious..."
    elif label == "PTSD":
        return "Audio recording: I can’t sleep without nightmares... I’m always on edge..."
    elif label == "OCD":
        return "Audio recording: There are germs everywhere, I need to wash my hands... Still not clean..."
    else:
        return "Audio recording: Today was a normal day. There are some challenges, but I can handle them."
